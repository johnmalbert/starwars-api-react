import './App.css';
import Home from './Components/Home';
import { Router } from '@reach/router';
import CustomPage from './Components/CustomPage';
function App() {
  return (
    <div className="App">
      <Router>
        <Home path="/:prop" />
        <CustomPage path="/:word/:font/:background" />
      </Router>
    </div>
  );
}

export default App;
