import React from 'react'

const Home = (props) => {
    const { prop } = props;
    return (
        <div>
            {
                prop === "home" ?
                <h1>Welcome</h1>:
                !isNaN(prop) ?
                <h1>The Number is {prop}</h1> :
                <h1>The word is {prop}</h1>
            }
        </div>
    )
}

export default Home
