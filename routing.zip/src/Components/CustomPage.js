import React from 'react'

const CustomPage = (props) => {
    const { word, font, background } = props;
    return (
        <div>
            <h1 style={{backgroundColor: background, color: font, border: "solid", padding: "1rem"}}>The word is: {word}</h1>
        </div>
    )
}

export default CustomPage
